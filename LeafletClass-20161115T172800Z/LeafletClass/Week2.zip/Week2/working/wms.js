var nexrad = 'http://mesonet.agron.iastate.edu/cgi-bin/wms/nexrad/n0r.cgi'

var terraDOQ = 'http://msrmaps.com/ogcmap.ashx?LAYERS=DOQ&FORMAT=image/jpeg&STYLES=&BGCOLOR=0xffffff&TRANSPARENT=TRUE'

var NAIP = 'http://raster.nationalmap.gov/ArcGIS/services/Orthoimagery/USGS_EDC_Ortho_NAIP/ImageServer/WMSServer?LAYERS=0&FORMAT=image/jpeg&BGCOLOR=0xffffff&TRANSPARENT=TRUE'

var 

